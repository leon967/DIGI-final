class PostMol {
  String article;
  String username;
  String time;
  String handle;

  PostMol(this.article, this.username, this.time, this.handle);
}
